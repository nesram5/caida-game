#!/bin/bash
exec python ./caida_game.py